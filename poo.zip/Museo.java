import java.time.Year;
import java.util.Locale;

class Museo {
    private String nombre;
    private String ciudad;
    private int anioInauguracion;
    private int capacidadVisitantes;
    private double costoEntrada;
    private int colecciones;
    private int visitantesAnuales;

    public Museo(String nombre, String ciudad, int anioInauguracion, int capacidadVisitantes, double costoEntrada, int colecciones, int visitantesAnuales) {
        this.nombre = nombre;
        this.ciudad = ciudad;
        this.anioInauguracion = anioInauguracion;
        this.capacidadVisitantes = capacidadVisitantes;
        this.costoEntrada = costoEntrada;
        this.colecciones = colecciones;
        this.visitantesAnuales = visitantesAnuales;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getCiudad() {
        return ciudad;
    }

    public void setCiudad(String ciudad) {
        this.ciudad = ciudad;
    }

    public int getAnioInauguracion() {
        return anioInauguracion;
    }

    public void setAnioInauguracion(int anioInauguracion) {
        this.anioInauguracion = anioInauguracion;
    }

    public int getCapacidadVisitantes() {
        return capacidadVisitantes;
    }

    public void setCapacidadVisitantes(int capacidadVisitantes) {
        this.capacidadVisitantes = capacidadVisitantes;
    }

    public double getCostoEntrada() {
        return costoEntrada;
    }

    public void setCostoEntrada(double costoEntrada) {
        this.costoEntrada = costoEntrada;
    }

    public int getColecciones() {
        return colecciones;
    }

    public void setColecciones(int colecciones) {
        this.colecciones = colecciones;
    }

    public int getVisitantesAnuales() {
        return visitantesAnuales;
    }

    public void setVisitantesAnuales(int visitantesAnuales) {
        this.visitantesAnuales = visitantesAnuales;
    }

    public int antiguedad() {
        int anioActual = Year.now().getValue();
        return anioActual - this.anioInauguracion;
    }

    public double ingresosAnuales() {
        return this.visitantesAnuales * this.costoEntrada;
    }

    public double promedioVisitantesPorColeccion() {
        if (this.colecciones > 0) {
            return (double) this.visitantesAnuales / this.colecciones;
        }
        return 0.0;
    }

    @Override
    public String toString() {
        return String.format(Locale.US,
            "Museo: %s\nCiudad: %s\nInauguración: %d\nCapacidad Diaria: %d\nCosto Entrada: %.2f pesos/col\nColecciones Permanentes: %d\nVisitantes Anuales: %d",
            nombre, ciudad, anioInauguracion, capacidadVisitantes, costoEntrada, colecciones, visitantesAnuales);
    }
}

class PruebaMuseo {
    public static void main(String[] args) {
        Museo museoDelPrado = new Museo(
            "Museo del Prado",
            "Madrid",
            1819,
            5000,
            120000.00,
            12,
            2000000
        );

        System.out.println("==========================================");
        System.out.println("         INFORMACIÓN DEL MUSEO");
        System.out.println("==========================================");
        System.out.println(museoDelPrado.toString());

        System.out.println("\n==========================================");
        System.out.println("         ANÁLISIS FINANCIERO Y OPERATIVO");
        System.out.println("==========================================");
        
        System.out.println("Antigüedad del Museo: " + museoDelPrado.antiguedad() + " años.");
        
        System.out.printf("Ingresos Anuales Estimados: %,.2f pesos/col\n", museoDelPrado.ingresosAnuales());
        
        System.out.printf("Promedio de Visitantes por Colección: %,.2f visitantes/colección\n", museoDelPrado.promedioVisitantesPorColeccion());
    }
}