class CuentaBancaria {
    private String numeroCuenta;
    private String titular;
    private double saldo;

    public CuentaBancaria() {
        this.numeroCuenta = "";
        this.titular = "";
        this.saldo = 0.0;
    }

    public CuentaBancaria(String numeroCuenta, String titular, double saldo) {
        this.numeroCuenta = numeroCuenta;
        this.titular = titular;
        this.saldo = saldo;
    }

    public String getNumeroCuenta() {
        return numeroCuenta;
    }

    public void setNumeroCuenta(String numeroCuenta) {
        this.numeroCuenta = numeroCuenta;
    }

    public String getTitular() {
        return titular;
    }

    public void setTitular(String titular) {
        this.titular = titular;
    }

    public double getSaldo() {
        return saldo;
    }

    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }

    public void depositar(double monto) {
        if (monto > 0) {
            this.saldo += monto;
            System.out.println("Depósito exitoso de: " + monto);
        } else {
            System.out.println("Error: El monto a depositar debe ser positivo.");
        }
    }

    public void retirar(double monto) {
        if (monto > 0) {
            if (this.saldo >= monto) {
                this.saldo -= monto;
                System.out.println("Retiro exitoso de: " + monto);
            } else {
                System.out.println("Error: Saldo insuficiente. El saldo actual es: " + this.saldo);
            }
        } else {
            System.out.println("Error: El monto a retirar debe ser positivo.");
        }
    }

    @Override
    public String toString() {
        return "CuentaBancaria [Número de Cuenta: " + numeroCuenta +
               ", Titular: " + titular +
               ", Saldo: " + saldo + "]";
    }
}

 class PruebaCuentaBancaria {
    public static void main(String[] args) {
        CuentaBancaria miCuenta = new CuentaBancaria("1234567890", "Juan Pérez", 500.00);

        System.out.println("--- Estado Inicial ---");
        System.out.println(miCuenta.toString());

        System.out.println("\n--- Operación: Depósito ---");
        miCuenta.depositar(250.50);
        System.out.println("Nuevo Saldo: " + miCuenta.getSaldo());

        System.out.println("\n--- Operación: Retiro con éxito ---");
        miCuenta.retirar(100.00);
        System.out.println("Nuevo Saldo: " + miCuenta.getSaldo());
        
        System.out.println("\n--- Operación: Retiro fallido (saldo insuficiente) ---");
        miCuenta.retirar(1000.00);
        System.out.println("Saldo se mantiene en: " + miCuenta.getSaldo());

        System.out.println("\n--- Estado Final ---");
        System.out.println(miCuenta.toString());
    }
}