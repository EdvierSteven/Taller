import java.util.Locale;

class Estudiante {
    private String nombre;
    private int edad;
    private String carrera;
    private double promedio;

    public Estudiante() {
        this.nombre = "";
        this.edad = 0;
        this.carrera = "";
        this.promedio = 0.0;
    }

    public Estudiante(String nombre, int edad, String carrera, double promedio) {
        this.nombre = nombre;
        this.edad = edad;
        this.carrera = carrera;
        this.promedio = promedio;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public String getCarrera() {
        return carrera;
    }

    public void setCarrera(String carrera) {
        this.carrera = carrera;
    }

    public double getPromedio() {
        return promedio;
    }

    public void setPromedio(double promedio) {
        this.promedio = promedio;
    }

    public boolean aprobo() {
        return this.promedio >= 3.0;
    }

    public boolean esMayorEdad() {
        return this.edad >= 18;
    }

    @Override
    public String toString() {
        return String.format(Locale.US, "Estudiante [Nombre: %s, Edad: %d, Carrera: %s, Promedio: %.1f]",
                             nombre, edad, carrera, promedio);
    }
}

class PruebaEstudiante {
    public static void main(String[] args) {
        Estudiante estudiante1 = new Estudiante(
            "Sofía Pérez",
            21,
            "Ingeniería de Sistemas",
            4.2
        );

        System.out.println("--- Datos del Estudiante ---");
        System.out.println(estudiante1.toString());
        
        System.out.println("\n--- Resultados ---");
        
        System.out.print("¿Aprobó el semestre (>3.0)? ");
        System.out.println(estudiante1.aprobo() ? "✅ Sí, aprobó." : "❌ No, no aprobó.");

        System.out.print("¿Es mayor de edad (>=18)? ");
        System.out.println(estudiante1.esMayorEdad() ? "✅ Sí, es mayor de edad." : "❌ No, es menor de edad.");
    }
}
