import java.time.Year;

public class Libro {
    private String titulo;
    private String autor;
    private int numeroPaginas;
    private int anioPublicacion;

    public Libro() {
        this.titulo = "";
        this.autor = "";
        this.numeroPaginas = 0;
        this.anioPublicacion = Year.now().getValue();
    }

    public Libro(String titulo, String autor, int numeroPaginas, int anioPublicacion) {
        this.titulo = titulo;
        this.autor = autor;
        this.numeroPaginas = numeroPaginas;
        this.anioPublicacion = anioPublicacion;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public int getNumeroPaginas() {
        return numeroPaginas;
    }

    public void setNumeroPaginas(int numeroPaginas) {
        this.numeroPaginas = numeroPaginas;
    }

    public int getAnioPublicacion() {
        return anioPublicacion;
    }

    public void setAnioPublicacion(int anioPublicacion) {
        this.anioPublicacion = anioPublicacion;
    }

    public boolean esAntiguo() {
        int anioActual = Year.now().getValue();
        return (anioActual - this.anioPublicacion) > 20;
    }

    @Override
    public String toString() {
        return "Libro [Título: " + titulo +
               ", Autor: " + autor +
               ", Páginas: " + numeroPaginas +
               ", Año de Publicación: " + anioPublicacion +
               "]";
    }
}

class PruebaLibro {
    public static void main(String[] args) {
        Libro libro1 = new Libro(
            "Crónica de una muerte anunciada",
            "Gabriel García Márquez",
            140,
            1981
        );

        Libro libro2 = new Libro();
        libro2.setTitulo("El Programador Limpio");
        libro2.setAutor("Robert C. Martin");
        libro2.setNumeroPaginas(462);
        libro2.setAnioPublicacion(2008);

        System.out.println(libro1.toString());
        System.out.println(libro2.toString());
        System.out.println("--------------------");

        System.out.print("¿'" + libro1.getTitulo() + "' es antiguo? ");
        System.out.println(libro1.esAntiguo() ? "Sí, tiene más de 20 años." : "No, es reciente.");

        System.out.print("¿'" + libro2.getTitulo() + "' es antiguo? ");
        System.out.println(libro2.esAntiguo() ? "Sí, tiene más de 20 años." : "No, es reciente.");
    }
}