import java.time.Year;

class Pelicula {
    private String titulo;
    private String director;
    private int duracionMinutos;
    private int anioEstreno;

    public Pelicula() {
        this.titulo = "";
        this.director = "";
        this.duracionMinutos = 0;
        this.anioEstreno = Year.now().getValue();
    }

    public Pelicula(String titulo, String director, int duracionMinutos, int anioEstreno) {
        this.titulo = titulo;
        this.director = director;
        this.duracionMinutos = duracionMinutos;
        this.anioEstreno = anioEstreno;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getDirector() {
        return director;
    }

    public void setDirector(String director) {
        this.director = director;
    }

    public int getDuracionMinutos() {
        return duracionMinutos;
    }

    public void setDuracionMinutos(int duracionMinutos) {
        this.duracionMinutos = duracionMinutos;
    }

    public int getAnioEstreno() {
        return anioEstreno;
    }

    public void setAnioEstreno(int anioEstreno) {
        this.anioEstreno = anioEstreno;
    }

    public boolean esLarga() {
        return this.duracionMinutos > 120;
    }

    public int antiguedad() {
        int anioActual = Year.now().getValue();
        return anioActual - this.anioEstreno;
    }

    @Override
    public String toString() {
        return "Pelicula [Título: " + titulo +
               ", Director: " + director +
               ", Duración: " + duracionMinutos + " min" +
               ", Año de Estreno: " + anioEstreno + "]";
    }
}

class PruebaPelicula {
    public static void main(String[] args) {
        Pelicula miPelicula = new Pelicula(
            "Avatar: El Camino del Agua",
            "James Cameron",
            192,
            2022
        );

        System.out.println("--- Ficha de la Película ---");
        System.out.println(miPelicula.toString());
        
        System.out.println("\n--- Análisis ---");
        
        System.out.print("¿Es una película larga (>120 min)? ");
        System.out.println(miPelicula.esLarga() ? "✅ Sí." : "❌ No.");

        System.out.print("Antigüedad: ");
        System.out.println(miPelicula.antiguedad() + " años.");
    }
}