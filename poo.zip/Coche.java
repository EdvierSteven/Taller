import java.time.Year;

class Coche {
    private String marca;
    private String modelo;
    private int anioFabricacion;
    private int velocidadMaxima;

    public Coche() {
        this.marca = "";
        this.modelo = "";
        this.anioFabricacion = Year.now().getValue();
        this.velocidadMaxima = 0;
    }

    public Coche(String marca, String modelo, int anioFabricacion, int velocidadMaxima) {
        this.marca = marca;
        this.modelo = modelo;
        this.anioFabricacion = anioFabricacion;
        this.velocidadMaxima = velocidadMaxima;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public int getAnioFabricacion() {
        return anioFabricacion;
    }

    public void setAnioFabricacion(int anioFabricacion) {
        this.anioFabricacion = anioFabricacion;
    }

    public int getVelocidadMaxima() {
        return velocidadMaxima;
    }

    public void setVelocidadMaxima(int velocidadMaxima) {
        this.velocidadMaxima = velocidadMaxima;
    }

    public int edadCoche() {
        int anioActual = Year.now().getValue();
        return anioActual - this.anioFabricacion;
    }

    public boolean esRapido() {
        return this.velocidadMaxima > 200;
    }

    @Override
    public String toString() {
        return "Coche [Marca: " + marca +
        
               ", Modelo: " + modelo +
               ", Año de Fabricación: " + anioFabricacion +
               ", Velocidad Máxima: " + velocidadMaxima + " km/h" +
               "]";
    }
}

class PruebaCoche {
    public static void main(String[] args) {
        Coche coche1 = new Coche(
            "Porsche",
            "911 Turbo S",
            2024,
            330
        );

        Coche coche2 = new Coche();
        coche2.setMarca("Volkswagen");
        coche2.setModelo("Golf");
        coche2.setAnioFabricacion(2018);
        coche2.setVelocidadMaxima(190);

        System.out.println("--- Coche 1 ---");
        System.out.println(coche1.toString());
        System.out.println("Edad del coche: " + coche1.edadCoche() + " años.");
        System.out.print("¿Es rápido (>200 km/h)? ");
        System.out.println(coche1.esRapido() ? "Sí." : "No.");

        System.out.println("\n--- Coche 2 ---");
        System.out.println(coche2.toString());
        System.out.println("Edad del coche: " + coche2.edadCoche() + " años.");
        System.out.print("¿Es rápido (>200 km/h)? ");
        System.out.println(coche2.esRapido() ? "Sí." : "No.");
    }
}